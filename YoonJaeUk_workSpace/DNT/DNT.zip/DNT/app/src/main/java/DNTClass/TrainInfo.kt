package DNTClass

// writer : Yoon Jae Uk
// date : 2022.04.29 ~ ?
// content : 기차 정보를 담고있는 클래스이다.

/* class and member init declaration begin */
class TrainInfo (){


/* class and member init declaration end */

    /* class method declaration begin */
    /* class method declaration end */
}
package com.example.dnt.layout

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dnt.R

class TrainPeopleNumActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_train_people_num)
    }
}